// P1: I was born in 1980
// P2: I was born in 1980
// P3: Summing Numbers!
//      num1 is: 10
//      num2 is: 20
//      30
