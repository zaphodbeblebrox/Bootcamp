function incrementLikes(likeID){
    document.querySelector(likeID).innerHTML++;
}