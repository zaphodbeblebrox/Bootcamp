function changeColor(circle, color){
    circle.style.backgroundColor = color;
}