console.log("page loaded...");

function over(xThis){
    xThis.play();
}

function out(xThis){
    xThis.pause();
}